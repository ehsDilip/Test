<?php
include 'ehs_data.php';

//$all_country=  get_all_ehs_country();
//echo "<pre>";
//print_r($all_country);

//$region= fetch_ehs_region(array(1,2));
//echo "<pre>";
//print_r($region);

//$city= fetch_ehs_city(array(1,2));
//echo "<pre>";
//print_r($city);